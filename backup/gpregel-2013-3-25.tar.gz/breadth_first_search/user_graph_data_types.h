struct Global {
  unsigned int source;
};

struct Vertex {
  out unsigned int level = ~0U;
};

struct Edge {
};

struct Message {
  unsigned int level;
};
