struct Global {
};

struct Vertex {
  in bool left;
  out unsigned int match_id = ~0u;
};

struct Edge {
};

struct Message {
};
