// *****************************************************************************
// Filename:    reading_thread.h
// Date:        2012-12-07 19:19
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#ifndef READING_THREAD_H_
#define READING_THREAD_H_

void* ReadingThread(void *args);

#endif
