// *****************************************************************************
// Filename:    rand_util.cc
// Date:        2013-01-01 17:00
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#include "rand_util.h"

unsigned int RandUtil::num_vertexes = ~0U;
