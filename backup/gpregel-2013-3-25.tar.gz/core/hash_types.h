// *****************************************************************************
// Filename:    hash_types.h
// Date:        2012-12-10 11:26
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#ifndef HASH_TYPES_H_
#define HASH_TYPES_H_

typedef unsigned int HashType;

const unsigned int HASH_MOD = 0;
const unsigned int HASH_SPLIT = 1;

#endif
