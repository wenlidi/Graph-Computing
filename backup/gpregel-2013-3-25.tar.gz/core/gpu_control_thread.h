// *****************************************************************************
// Filename:    gpu_control_thread.h
// Date:        2012-12-07 15:07
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#ifndef GPU_CONTROL_THREAD_H_
#define GPU_CONTROL_THREAD_H_

void* GPUControlThread(void *args);

#endif
