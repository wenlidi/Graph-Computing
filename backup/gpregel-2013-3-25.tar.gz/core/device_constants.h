// *****************************************************************************
// Filename:    device_constants.h
// Date:        2012-12-27 14:14
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#ifndef DEVICE_CONSTANTS_H_
#define DEVICE_CONSTANTS_H_

// NOTE: This file could only be involved in one and only one .cu file.

__device__ const unsigned int dkMaxUInt = ~0U;

#endif
