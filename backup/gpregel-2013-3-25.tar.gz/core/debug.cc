// *****************************************************************************
// Filename:    debug.cc
// Date:        2012-12-13 15:39
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#include "debug.h"

#include "auto_mutex.h"

AutoMutex cout_lock;
