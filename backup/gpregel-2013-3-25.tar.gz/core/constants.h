// *****************************************************************************
// Filename:    constants.h
// Date:        2012-12-06 14:14
// Author:      Guangda Lai
// Email:       lambda2fei@gmail.com
// Description: TODO(laigd): Put the file description here.
// *****************************************************************************

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

const unsigned int kMaxNumGPUs = 32;

const unsigned int kMaxUInt = ~0U;

const float kMaxFloate = 3.40e+38;

#endif
