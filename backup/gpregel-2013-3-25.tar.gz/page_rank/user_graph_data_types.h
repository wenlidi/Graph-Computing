struct Global {
};

struct Vertex {
  out float rank = 99.0f;
};

struct Edge {
};

struct Message {
  float rank;
};
